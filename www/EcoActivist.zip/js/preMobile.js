// JavaScript Document
//Override the default setting
$(document).bind("mobileinit", function(){
	$.mobile.defaultPageTransition = 'slide';
});